<?php
/**
 * The template for displaying the footer
 *
 * @package TingTongTheme
 */
?>

<?php wp_footer(); ?>
</body>
</html>