export default [
  {
    files: ["script.js"],
    rules: {
      "no-unused-vars": "warn",
      "no-console": "warn"
    }
  }
];